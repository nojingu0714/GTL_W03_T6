#pragma once

#include "Object.h"

struct FRay;
class UDirectXHandle;
class AGizmoActor;

enum class GizmoState
{
	None,
	Translate,
	Rotate,
	Scale,
};

class FGizmoManager
{

public:
	FGizmoManager();

	void Init();
	void Tick(float DeltaTime);
	
	void ProcessInput(FRay Ray);

	void Destroy();

	AGizmoActor* GetGizmoActor() const { return GizmoActor; }

private:
	AGizmoActor* GizmoActor;
};

