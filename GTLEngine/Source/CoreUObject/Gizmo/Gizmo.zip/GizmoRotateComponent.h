#pragma once

#include "Components/StaticMeshComponent.h"

class UGizmoRotateMesh : public UStaticMeshComponent
{
	DECLARE_CLASS(UGizmoRotateMesh, UStaticMeshComponent)

public:
	UGizmoRotateMesh();

};