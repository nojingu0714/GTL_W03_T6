#pragma once

#include "Components/StaticMeshComponent.h"

class UGizmoScaleMesh : public UStaticMeshComponent
{
	DECLARE_CLASS(UGizmoScaleMesh, UStaticMeshComponent)

public:
	UGizmoScaleMesh();

};