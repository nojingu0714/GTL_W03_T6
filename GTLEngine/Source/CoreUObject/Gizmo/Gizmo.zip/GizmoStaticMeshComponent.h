#pragma once

#include "Components/StaticMeshComponent.h"

// GizmoTranslate.obj : x: 0 - 1.724, y:0 - 0.7, z: 0 - 0.7
class UGizmoTranslateMesh : public UStaticMeshComponent
{
	DECLARE_CLASS(UGizmoTranslateMesh, UStaticMeshComponent)

public:
	UGizmoTranslateMesh();

	bool Intersects(const FRay ray, float& distance) const;
	
private:
	const FBoundingBox LocalBox = FBoundingBox(FVector(1.724, 0.7, 0.7), FVector(0, -0.7, -0.7));
};


// +x, +y 방향으로 0.88f, 1.0f
class UGizmoRotateMesh : public UStaticMeshComponent
{
	DECLARE_CLASS(UGizmoRotateMesh, UStaticMeshComponent)

public:
	UGizmoRotateMesh();

	bool Intersects(const FRay ray, float& distance) const;

private:
	const float InnerRadius = 0.88f;
	const float OuterRadius = 1.0f;
};

class UGizmoScaleMesh : public UStaticMeshComponent
{
	DECLARE_CLASS(UGizmoScaleMesh, UStaticMeshComponent)

public:
	UGizmoScaleMesh();

	bool Intersects(const FRay ray, float& distance) const;

	const FBoundingBox LocalBox = FBoundingBox(FVector(1.724, 0.7, 0.7), FVector(0, -0.7, -0.7));

};

